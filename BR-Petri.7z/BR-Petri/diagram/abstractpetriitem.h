#ifndef PETRIITEM_H
#define PETRIITEM_H

#include <QGraphicsPolygonItem>
#include <QList>
/*
class QPixmap;
class QGraphicsItem;
class QGraphicsScene;
class QTextEdit;
class QGraphicsSceneMouseEvent;
class QMenu;
class QGraphicsSceneContextMenuEvent;
class QPainter;
class QStyleOptionGraphicsItem;
class QWidget;
class QPolygonF;*/

class AbstractPetriArc;

class AbstractPetriItem : public QGraphicsPolygonItem
{
public:
    enum { Type = UserType + 15 };
    enum PetriType { Place, FPlace, ITrans, TTrans };

    AbstractPetriItem(QMenu *contextMenu, QGraphicsItem *parent=nullptr);
    virtual ~AbstractPetriItem();

    void removeArc(AbstractPetriArc *arc);
    void removeArcs();
    PetriType petriType() const { return myPetriType; }
    QPolygonF polygon() const { return myPoligon; }
    void addArc(AbstractPetriArc* arc);
    QPixmap image() const;
    int type() const Q_DECL_OVERRIDE { return Type; }

    bool isPlace();
    bool isTransition();

protected:
    void contextMenuEvent(QGraphicsSceneContextMenuEvent *event) Q_DECL_OVERRIDE;
    QVariant itemChange(GraphicsItemChange change, const QVariant &value) Q_DECL_OVERRIDE;

    PetriType myPetriType;
    QPolygonF myPoligon;
    QMenu *myContextMenu;
    QList<AbstractPetriArc*> arcs;

    virtual void drawItem();
};

#endif // PETRIITEM_H
