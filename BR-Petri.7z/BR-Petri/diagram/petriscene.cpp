#include "petriscene.h"

#include "abstractpetriarc.h"
#include <QTextCursor>
#include <QGraphicsSceneMouseEvent>

PetriScene::PetriScene(QMenu *itemMenu, QObject *parent)
    :QGraphicsScene(parent)
{
    this->myItemMenu = itemMenu;
    myMode = MoveItem;
    myItemType = AbstractPetriItem::PetriType::Place;
    line = nullptr;
    textItem = nullptr;
    myItemColor = Qt::white;
    myTextColor = Qt::black;
    myLineColor = Qt::black;
}

void PetriScene::setLineColor(const QColor &color)
{

}

void PetriScene::setTextColor(const QColor &color)
{

}

void PetriScene::setItemColor(const QColor &color)
{

}

void PetriScene::setFont(const QFont &font)
{

}

void PetriScene::setMode(PetriScene::Mode mode)
{

}

void PetriScene::setItemtype(AbstractPetriItem::PetriType type)
{

}

void PetriScene::editorLostFocus(PetriTextItem *item)
{

}

void PetriScene::mousePressEvent(QGraphicsSceneMouseEvent *mouseEvent)
{

}

void PetriScene::mouseMoveEvent(QGraphicsSceneMouseEvent *mouseEvent)
{

}

void PetriScene::mouseReleaseEvent(QGraphicsSceneMouseEvent *mouseEvent)
{

}

