#include "placeitem.h"

#include <QPainter>

PlaceItem::PlaceItem(QMenu *contextMenu, QGraphicsItem *parent):AbstractPetriItem(contextMenu, parent)
{
    myPetriType = PetriType::Place;
}

PlaceItem::~PlaceItem()
{

}

void PlaceItem::drawItem()
{
    QPainterPath path;
    path.addEllipse(100, 100, 50, 50);
    myPoligon = path.toFillPolygon();
    AbstractPetriItem::drawItem();
}

